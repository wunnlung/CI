//Evan Gray - May 2012
//Compile: gcc Spinner.c libcAI.so -o Spinner
//Run: ./Spinner
#include "cAI.h"
#include <stdio.h>
AI_loop() {
  turnLeft(1);
}
int main(int argc, char *argv[]) {
  return start(argc, argv);
}